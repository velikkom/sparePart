package com.velikkom.demo.entity.enums;

public enum RoleType {
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_PLASIYER

}
